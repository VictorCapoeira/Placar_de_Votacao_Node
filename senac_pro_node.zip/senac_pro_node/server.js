// Servidor HTTP e utilitários
const express = require('express');
const path = require('path');
// Driver MySQL com suporte a Promises
const mysql = require('mysql2/promise');

const app = express();

// Configuração básica via variáveis de ambiente (com padrões para desenvolvimento local)
const PORT = process.env.PORT || 3000;
const DB_HOST = process.env.DB_HOST || 'localhost';
const DB_USER = process.env.DB_USER || 'root';
const DB_PASSWORD = process.env.DB_PASSWORD || '';
const DB_NAME = process.env.DB_NAME || 'sistema_de_votos';

// Cria um pool de conexões para eficiência e reuso (cada requisição pega uma, usa e devolve)
const pool = mysql.createPool({
    host: DB_HOST,
    user: DB_USER,
    password: DB_PASSWORD,
    database: DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Habilita parse de JSON no corpo das requisições
app.use(express.json());
// Servir os arquivos estáticos da pasta public (frontend)
app.use(express.static(path.join(__dirname, 'public')));

// Health check simples para verificar se o servidor está no ar
app.get('/api/health', (_req, res) => {
    res.json({ ok: true, time: new Date().toISOString() });
});

// GET /api/turmas -> retorna turmas do banco conforme schema fornecido
// Observação: fotos_turma pode ser JSON (array) ou string com URLs separadas por vírgula
app.get('/api/turmas', async (_req, res) => {
    try {
        const sql = `
            SELECT t.id_turma,
                   t.nome_turma,
                   t.codigo_turma,
                   t.projeto_turma,
                   t.descricao_projeto_turma,
                   t.fotos_turma,
                   t.professor_turma
            FROM turma t
            ORDER BY t.id_turma ASC
        `;
        const [rows] = await pool.query(sql);

        // Mapeia para o formato esperado pelo frontend
        const turmas = rows.map(r => {
            // Parse de fotos_turma: aceita JSON de array ou lista separada por vírgulas
            let images = [];
            if (r.fotos_turma) {
                const s = String(r.fotos_turma).trim();
                try {
                    const parsed = JSON.parse(s);
                    if (Array.isArray(parsed)) images = parsed.filter(Boolean);
                } catch {
                    // não é JSON, tenta split por vírgula
                    images = s.split(',').map(x => x.trim()).filter(Boolean);
                }
            }
            if (images.length === 0) {
                images = [
                    'https://placehold.co/600x400/004A8D/white?text=' + encodeURIComponent(r.nome_turma)
                ];
            }

            return {
                id: r.id_turma,
                code: r.codigo_turma,
                name: r.nome_turma,
                description: r.descricao_projeto_turma || r.projeto_turma || '',
                teacher: r.professor_turma || '',
                images
            };
        });

        res.json(turmas);
    } catch (err) {
        // Log detalhado para diagnóstico de problemas de banco
        console.error('Erro ao buscar turmas:', err.message, err.code || '', err.sqlMessage || '');
        res.status(500).json({ error: 'Falha ao buscar turmas no banco de dados.' });
    }
});

// POST /api/vote -> body: { cpf: string (11 dígitos), id_turma: number }
// Regras:
// - Cria o usuário (CPF) se não existir
// - Apenas um voto por CPF (bloqueia voto duplicado)
// - Usa transação para consistência
app.post('/api/vote', async (req, res) => {
    const { cpf, id_turma } = req.body || {};
    if (!cpf || String(cpf).length !== 11 || !/^[0-9]{11}$/.test(String(cpf))) {
        return res.status(400).json({ error: 'CPF inválido. Use 11 dígitos numéricos.' });
    }
    if (!id_turma || isNaN(Number(id_turma))) {
        return res.status(400).json({ error: 'id_turma inválido.' });
    }

    const conn = await pool.getConnection();
    try {
        await conn.beginTransaction(); // inicia transação

        // Garante que a turma existe
        const [[turma]] = await conn.query('SELECT id_turma FROM turma WHERE id_turma = ?', [id_turma]);
        if (!turma) {
            await conn.rollback();
            return res.status(404).json({ error: 'Turma não encontrada.' });
        }

        // Busca/cria usuário
        let [[user]] = await conn.query('SELECT id_usuario FROM usuario WHERE cpf = ?', [cpf]);
        if (!user) {
            const [result] = await conn.query('INSERT INTO usuario (cpf) VALUES (?)', [cpf]);
            user = { id_usuario: result.insertId };
        }

        // Verifica se já votou (uma vez por usuário)
        const [[already]] = await conn.query('SELECT id_votos FROM votos WHERE id_usuario = ?', [user.id_usuario]);
        if (already) {
            await conn.rollback();
            return res.status(409).json({ error: 'Este CPF já registrou um voto.' });
        }

        // Registra voto
        await conn.query('INSERT INTO votos (id_usuario, id_turma) VALUES (?, ?)', [user.id_usuario, id_turma]);
        await conn.commit(); // finaliza transação com sucesso
        res.status(201).json({ ok: true });
    } catch (err) {
        await conn.rollback(); // desfaz alterações em caso de erro
        // Log detalhado para diagnóstico
        console.error('Erro ao registrar voto:', err.message, err.code || '', err.sqlMessage || '');
        res.status(500).json({ error: 'Falha ao registrar voto.' });
    } finally {
        conn.release(); // devolve a conexão ao pool
    }
});

// GET /api/placar -> retorna votos agregados por turma (ordem decrescente)
app.get('/api/placar', async (_req, res) => {
    try {
        const sql = `
            SELECT t.id_turma,
                   t.nome_turma,
                   t.professor_turma,
                   COUNT(v.id_votos) AS votos
            FROM turma t
            LEFT JOIN votos v ON v.id_turma = t.id_turma
            GROUP BY t.id_turma, t.nome_turma, t.professor_turma
            ORDER BY votos DESC, t.nome_turma ASC
        `;
        const [rows] = await pool.query(sql);
        const total = rows.reduce((acc, r) => acc + Number(r.votos || 0), 0);
        res.json({ total, results: rows });
    } catch (err) {
        console.error('Erro ao obter placar:', err.message, err.code || '', err.sqlMessage || '');
        res.status(500).json({ error: 'Falha ao obter placar.' });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});

