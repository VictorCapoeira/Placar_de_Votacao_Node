USE sistema_de_votos;

INSERT INTO turma (nome_turma, codigo_turma, projeto_turma, descricao_projeto_turma, professor_turma, fotos_turma)
VALUES ("Enfermagem", "034", "Saude e Tecnologia", "Saude e Tecnologia", "Leonardo", "CaminhoTeste");
 
INSERT INTO turma (nome_turma, codigo_turma, projeto_turma, descricao_projeto_turma, professor_turma, fotos_turma)
VALUES ("turmafantasia", "codigofantasia", "Projeto fantasia", "descricaofantasia", "nomeprofessorfantasia", "fotosturmafantasia");
 
INSERT INTO turma (nome_turma, codigo_turma, projeto_turma, descricao_projeto_turma, professor_turma, fotos_turma)
VALUES ("turmafantasia", "codigofantasia", "Projeto fantasia", "descricaofantasia", "nomeprofessorfantasia", "fotosturmafantasia");
 
INSERT INTO turma (nome_turma, codigo_turma, projeto_turma, descricao_projeto_turma, professor_turma, fotos_turma)
VALUES ("turmafantasia", "codigofantasia", "Projeto fantasia", "descricaofantasia", "nomeprofessorfantasia", "fotosturmafantasia");
 
INSERT INTO turma (nome_turma, codigo_turma, projeto_turma, descricao_projeto_turma, professor_turma, fotos_turma)
VALUES ("turmafantasia", "codigofantasia", "Projeto fantasia", "descricaofantasia", "nomeprofessorfantasia", "fotosturmafantasia");
 
INSERT INTO turma (nome_turma, codigo_turma, projeto_turma, descricao_projeto_turma, professor_turma, fotos_turma)
VALUES ("turmafantasia", "codigofantasia", "Projeto fantasia", "descricaofantasia", "nomeprofessorfantasia", "fotosturmafantasia");
 
INSERT INTO turma (nome_turma, codigo_turma, projeto_turma, descricao_projeto_turma, professor_turma, fotos_turma)
VALUES ("turmafantasia", "codigofantasia", "Projeto fantasia", "descricaofantasia", "nomeprofessorfantasia", "fotosturmafantasia");
 
INSERT INTO turma (nome_turma, codigo_turma, projeto_turma, descricao_projeto_turma, professor_turma, fotos_turma)
VALUES ("turmafantasia", "codigofantasia", "Projeto fantasia", "descricaofantasia", "nomeprofessorfantasia", "fotosturmafantasia");
 
INSERT INTO turma (nome_turma, codigo_turma, projeto_turma, descricao_projeto_turma, professor_turma, fotos_turma)
VALUES ("turmafantasia", "codigofantasia", "Projeto fantasia", "descricaofantasia", "nomeprofessorfantasia", "fotosturmafantasia");
 
INSERT INTO turma (nome_turma, codigo_turma, projeto_turma, descricao_projeto_turma, professor_turma, fotos_turma)
VALUES ("turmafantasia", "codigofantasia", "Projeto fantasia", "descricaofantasia", "nomeprofessorfantasia", "fotosturmafantasia");
 
 INSERT INTO turma (nome_turma,codigo_turma, projeto_turma, descricao_projeto_turma,professor_turma, fotos_turma)
VALUES ("turmafantasia", "codigofantasia", "Projeto fantasia", "descricaofantasia","nomeprofessorfantasia", "fotosturmafantasia");
 
